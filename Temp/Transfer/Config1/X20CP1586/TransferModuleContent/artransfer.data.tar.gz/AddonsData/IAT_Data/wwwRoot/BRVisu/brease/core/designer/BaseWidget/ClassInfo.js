define(['brease/core/designer/BaseWidget/ClassExtension'], function (classExtension) {

    'use strict';

    return {

    };
});
